<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          's<&XF;}C~s6LI>!.#k*`IE>}s*pG1{P4)}N)1DhF,WCbfJpWZ4k=rt7mAH7+wl}y' );
define( 'SECURE_AUTH_KEY',   'smF-(A?^oGRArVc1dn^=_bRkT8m6E@T7ytuM#2t11m{vK_jALU3-H]&BEf{/]K?Z' );
define( 'LOGGED_IN_KEY',     '=z{v~MJ0H:>(e/ia=WJGp9q7}G__ljzd!_Hd5#y&[xP&(!Q}G*_7M(8pU}#mh*)[' );
define( 'NONCE_KEY',         '7i#<L4pGe4~4hn{(Wzh4?f9!;3L{K<](mx/EP8njPM :E =0[wX/[(j%eJC-wi)_' );
define( 'AUTH_SALT',         'zvR{A:P{sVjA,kt}v(sG/ujx%lmpUm)q&uz}gP+)%2~3Gso_>SxHS(:9)]|O[8Bg' );
define( 'SECURE_AUTH_SALT',  ')m4x8]cj^/8b@:g,G}z}&TtuQu5hHAizsUn]?H8n$|IQ6;_)E!v>br`h<%c%3`aD' );
define( 'LOGGED_IN_SALT',    '2lxNsOd..>SJm o^K%3WE@B!+oU-3O0R,<w6_di4hF&hlN{1vT,3T)(Km1;0<$F@' );
define( 'NONCE_SALT',        '6,.I40A`pH9m%Zoiu(k;Ui2},X-+dUv)J^g:#*uF.@4PJ[Mu^ZqM[SL/;[93<0uq' );
define( 'WP_CACHE_KEY_SALT', ';iueNfnzrfR1xCbDNJ:o)!..)a# Mev~hAH49I]X/qs@_nhS}<=>zUU[?M<:!`>k' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
